CREATE database ToysGroup;

CREATE TABLE Category (
    CategoryID INT PRIMARY KEY,
    CategoryName VARCHAR(50) NOT NULL);
    
    CREATE TABLE Product (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    CategoryID INT,
    Price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
);
CREATE TABLE Region (
    RegionID INT PRIMARY KEY AUTO_INCREMENT,
    RegionName VARCHAR(50) NOT NULL
);

CREATE TABLE State (
    StateID INT PRIMARY KEY,
    StateName VARCHAR(50) NOT NULL,
    RegionID INT,
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)
);
CREATE TABLE Sales (
    SalesID INT PRIMARY KEY,
    ProductID INT,
    RegionID INT,
    DateOrder DATE,
    Quantity INT,
    Amount DECIMAL(10, 2),
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (RegionID) REFERENCES Region(RegionID)) ;

INSERT INTO Category (CategoryID,CategoryName) VALUES ('1','Peluche') ,
('2','Bambole'),
('3','Maschere');


INSERT INTO Product (ProductID, ProductName, CategoryID, Price) VALUES 
(4, 'Topolino', 1, 300.00), 
(5, 'Barbie', 2, 450.00),
(6, 'Maschere Halloween', 3, 20.00);

INSERT INTO Region (RegionID,RegionName) VALUES ('1','SouthEurope')
, ('2','NothEuropa');
 
 INSERT INTO State (StateID,StateName,RegionID) VALUES
    (14, 'Italia', 1),
    (13, 'Malta', 1),
    (20, 'Svezia', 2),
    (21, 'Norvegia', 2);
    
    INSERT INTO Sales (SalesId, ProductID,DateOrder, RegionID, Quantity,Amount) VALUES 
(2001,4,'2024-01-03', 1, 2, 600),
(2002,5,'2024-03-05', 2, 4, 1800),
(2003,6,'2024-06-08', 2, 3, 60);


/*TASK 4 ESERCIZIO 1*/
SELECT 
    COUNT(DISTINCT CategoryID) = COUNT(CategoryID) AS c
FROM
    Category;
SELECT 
    COUNT(DISTINCT ProductID) = COUNT(ProductID) AS p
FROM
    Product;
SELECT 
    COUNT(DISTINCT RegionID) = COUNT(RegionID) AS r
FROM
    Region;
SELECT 
    COUNT(DISTINCT StateID) = COUNT(StateID) AS c
FROM
    State;
SELECT 
    COUNT(DISTINCT SalesID) = COUNT(SalesID) AS s
FROM
    Sales;


/*TASK 4 ESERCIZIO 2*/
 SELECT 
    S.SalesID AS 'Codice Documento',
    S.DateOrder AS 'Data',
    P.ProductName AS 'Nome Prodotto',
    C.CategoryName AS 'Categoria Prodotto',
    CO.StateName AS 'Nome Stato',
    R.RegionName AS 'Nome Regione',
    CASE
        WHEN DATEDIFF(CURDATE(), S.DateOrder) > 180 THEN 'TRUE'
        ELSE 'False'
    END 'VERO\FALSO'
FROM
    Sales S
        JOIN
    Product P ON S.ProductID = P.ID
        JOIN
    Category C ON P.CategoryID = C.CategoryID
        JOIN
    Region R ON S.RegionID = R.RegionID
        JOIN
    State CO ON R.RegionID = CO.RegionID;
    
    -- TASK 4 ESERCIZIO 3--
    SELECT 
    P.ProductName AS 'Nome Prodotto',
    SUM(S.Quantity) AS 'Totale Venduto'
FROM 
    Sales S
JOIN 
    Product P ON S.ProductID = P.ProductID
WHERE 
    S.DateOrder >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
GROUP BY 
    P.ProductName
HAVING 
    SUM(S.Quantity) > (
        SELECT 
            AVG(TotalQuantity) 
        FROM (
            SELECT 
                SUM(Quantity) AS TotalQuantity
            FROM 
                Sales
            WHERE 
                DateOrder >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
            GROUP BY 
                DATE(DateOrder)
        ) AS AvgSales
    );
    
    
    
    
    
    
   -- TASK 4 ESERCIZIO 4--
SELECT 
    p.ProductID, 
    p.ProductName, 
    s.DateOrder, 
    SUM(s.Amount) AS fatturato_totale_annuale
FROM 
    product p
JOIN 
     sales s ON p.ProductID = s.ProductID
GROUP BY 
    p.ProductID, p.ProductName, s.DateOrder;
    
    
 

    
   
    
    
    -- TASK 4 ESERCIZIO 5--
  SELECT 
    C.StateName AS State,
    YEAR(S.DateOrder) AS anno,
    SUM(S.Amount) AS FatturatoTot
FROM 
    Sales S
JOIN 
    State C ON S.RegionID = c.RegionID
GROUP BY 
    C.StateName, YEAR(S.DateOrder)
ORDER BY 
    anno ASC, FatturatoTot DESC;
    
    
    
    
	/* La categoria più venduta è quella delle bambole, TASK 4 ESERCIZIO 6*/
    SELECT 
    C.CategoryName,
    SUM(S.Quantity) AS TotaleVenduto
FROM 
    Sales S
JOIN 
    Product P ON S.ProductID = P.ProductID
JOIN 
    Category C ON P.CategoryID = C.CategoryID
GROUP BY 
    C.CategoryName
ORDER BY 
    TotaleVenduto DESC
LIMIT 1;

/*non ci sono prodotti invenduti in questo caso specifico, TASK 4 ESERCIZIO 7*/
    SELECT 
    P.ProductID, 
    P.ProductName
FROM 
    Product P
LEFT JOIN 
    Sales S ON P.ProductID = S.ProductID
WHERE 
    S.SalesID IS NULL;
    
    
    /* secondo approccio*/
    SELECT 
    P.ProductID, 
    P.ProductName
FROM 
    Product P
WHERE 
    P.ProductID NOT IN (SELECT ProductID FROM Sales);
    
    -- TASK 4 ESERCIZIO 8--
    /*view versione denormalizzata*/
    CREATE VIEW Product_Denormalized AS
SELECT 
    P.ProductID AS CodiceProdotto,
    P.ProductName AS NomeProdotto,
    C.CategoryName AS NomeCategoria
FROM 
    Product P
JOIN 
    Category C ON P.CategoryID = C.CategoryID;
    
    
-- TASK 4 ESERCIZIO 9--
CREATE VIEW Geographic_Info AS
SELECT 
    T.StateID AS CodiceStato,
    T.StateName AS NomeStato,
    R.RegionID AS CodiceRegione,
    R.RegionName AS NomeRegione
FROM 
    State T
JOIN 
    Region R ON T.RegionID = R.RegionID;
    
    
    
    
    


    
    
    

    
    

      
      








